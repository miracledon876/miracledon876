import java.io.IOException;
import java.io.RandomAccessFile;

public class RandomAccessFileExample {
	static final String FILEPATH = "rand.txt";

	private static int calculateMemory(Pet p) {
		// int = 4 bytes
		// dobule = 8 bytes
		// char = 2 bytes
		int idSize = 4, charSize = 2, doubleSize = 8;
		int memory = idSize + (p.getType().length() * charSize) + charSize + doubleSize;
		return memory;
	}

	//starting byte tells us where should we start writing the record in the file
	// sb - starting byte
	// eb - ending byte
	// kfv - key field value [ID#]
	// offset - first valid ID#
	private static int calculateStartingByte(Pet p) {
		final int offset = 1; // first pet ID
		int memory = calculateMemory(p);
		int kfv = p.getId();
		int sb = (kfv - offset) * memory;
//    	int eb = sb + (memory - 1);
		return sb;
	}

	private static void writeToFile(String filePath, Pet p, int position) throws IOException {
		RandomAccessFile file = new RandomAccessFile(filePath, "rw");
		file.seek(position);
		file.writeInt(p.getId());
		file.writeUTF(p.getType());
		file.writeChar(p.getGender());
		file.writeDouble(p.getCost());
		file.close();
	}
	
	private static Pet readFromFile(String filePath, int position) throws IOException {
		Pet p = new Pet();
		RandomAccessFile file = new RandomAccessFile(filePath, "r");
		file.seek(position);
		p.setId(file.readInt());
		p.setType(file.readUTF());
		p.setGender(file.readChar());
		p.setCost(file.readDouble());
		file.close();
		return p;
	}

	public static void main(String[] args) {
		try {
			Pet p1 = new Pet(1, "cat", 'm', 500.0);
			Pet p2 = new Pet(2, "dog", 'f', 3300.0);
			Pet p3 = new Pet(6, "monkey", 'f', 800000.0);

			writeToFile(FILEPATH, p1, calculateStartingByte(p1));
			writeToFile(FILEPATH, p2, calculateStartingByte(p2));
			writeToFile(FILEPATH, p3, calculateStartingByte(p3));
//
//    	Pet filePet = readFromFile(FILEPATH, calculateStartingByte(p3)); 
//    	System.out.println(filePet.getId());
//    	System.out.println(filePet.getType());
//    	System.out.println(filePet.getGender());
//    	System.out.println(filePet.getCost());

		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}