
public class Pet {
	
	private int id;
	private String type;
	private char gender;
	private double cost;


	public Pet() {
		this.id = 0;
		this.type = "";
		this.gender = 'x';
		this.cost = 0.0;
	}

	
	public Pet(int id, String type, char gender, double cost) {
		super();
		this.id = id;
		this.type = type;
		this.gender = gender;
		this.cost = cost;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}


	public char getGender() {
		return gender;
	}


	public void setGender(char gender) {
		this.gender = gender;
	}


	public double getCost() {
		return cost;
	}


	public void setCost(double cost) {
		this.cost = cost;
	}
	
	
	
}
